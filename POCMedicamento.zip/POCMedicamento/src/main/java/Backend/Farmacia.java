/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Backend;

/**
 *
 * @author sotoj
 */
public class Farmacia {
    private int nit;
    private String razonSocial;
    private String represetanteLegal;
    private boolean estado;

    public Farmacia(int nit, String razonSocial, String represetanteLegal, boolean estado) {
        this.nit = nit;
        this.razonSocial = razonSocial;
        this.represetanteLegal = represetanteLegal;
        this.estado = estado;
    }

    public int getNit() {
        return nit;
    }

    public void setNit(int nit) {
        this.nit = nit;
    }

    public String getRazonSocial() {
        return razonSocial;
    }

    public void setRazonSocial(String razonSocial) {
        this.razonSocial = razonSocial;
    }

    public String getRepresetanteLegal() {
        return represetanteLegal;
    }

    public void setRepresetanteLegal(String represetanteLegal) {
        this.represetanteLegal = represetanteLegal;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
    
    
}
