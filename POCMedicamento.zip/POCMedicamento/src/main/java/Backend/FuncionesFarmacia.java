/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Backend;

import Frontend.GUIPrincipal;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import Backend.*;
import static Backend.FuncionesMedicamento.TAM_NOMBRE;
import static Backend.FuncionesMedicamento.adjustStringLength;

/**
 *
 * @author sotoj
 * 
 * ESTRUCTURA LECTURA DE FARMACIA
 *  private int nit; (4)
    private String razonSocial; (17)
    private String represetanteLegal; (17)
    private boolean estado; 1
 */
public class FuncionesFarmacia {
    
    public static final String NOM_ARCHIVO = "data//farmacia.txt";
    

    public static final int TAM_RAZON = 15;
    public static final int TAM_REPRESENTANTE = 15;
    public static final int TAM_REGISTRO_FAR = 39;
    
    public static boolean cargarEnArchivo(Farmacia far){
        Farmacia buscado = buscarFarmacia(far.getNit());

        if(buscado != null){
            return false;
        }
        try 
        {
            RandomAccessFile file = new RandomAccessFile(NOM_ARCHIVO, "rw");            
            
            file.seek(file.length());
            
            file.writeInt(far.getNit());
            file.writeUTF(FuncionesMedicamento.adjustStringLength(far.getRazonSocial(), TAM_RAZON));
            file.writeUTF(FuncionesMedicamento.adjustStringLength(far.getRepresetanteLegal(), TAM_REPRESENTANTE));
            file.writeBoolean(far.isEstado());
            
            
            file.close();
        
        } catch (Exception ex) {
            Logger.getLogger(GUIPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
        return true;
    }

    public static List listarFarmacias()
    {
        //Se declara una variable llamada medicamentos de tipo ArrayList que permite "almacenar" objetos de tipo Medicamento
        List <Farmacia> farmacias = new ArrayList();
        int nit;
        String razonSocial;
        String represetanteLegal;
        boolean estado;

        
        //Variable de tipo empleado - NO hay objeto aún
        Farmacia far;
        
        try 
        {
            RandomAccessFile file = new RandomAccessFile(NOM_ARCHIVO, "rw");
            //Se posiciona al inicio del archivo
            file.seek(0);
            while(file.getFilePointer() < file.length()){
                //Se leen los datos del archivo en el mismo orden en que fueron escritos
                nit = file.readInt();
                razonSocial = file.readUTF();
                represetanteLegal = file.readUTF();
                estado = file.readBoolean();

                //Crea un objeto de tipo Empleado (emp) a partir de los valores leidos del archivo. 
                far = new Farmacia(nit, razonSocial, represetanteLegal, estado);
                //Se adiciona al ArrayList empleados el empleado leido
                if(estado){
                    farmacias.add(far);
                }
            }
            file.close();
        } catch (Exception ex) {
            System.out.println("Error! " + ex);
        }

        return farmacias;
    }

    public static Farmacia buscarFarmacia(int nit)
    {
        int nitLeido;
        String razonSocial;
        String represetanteLegal;
        boolean estado;
        
        Farmacia far = null;

        try {
            RandomAccessFile file = new RandomAccessFile(NOM_ARCHIVO, "rw");
            //Se posiciona al inicio del archivo
            file.seek(0);
            while(file.getFilePointer() < file.length()){
                //Se leen los datos del archivo en el mismo orden en que fueron escritos
                nitLeido = file.readInt();
                razonSocial = file.readUTF();
                represetanteLegal = file.readUTF();
                estado = file.readBoolean();
                if(nitLeido == nit )
                {
                    far = new Farmacia(nit, razonSocial, represetanteLegal, estado);
                    break;
                    
                }
                else
                {
                    far = null;
                }
            }
            file.close();
        } catch (Exception ex) {
            System.out.println("Error! " + ex);
        }

        return far;
    }

    public static boolean eliminarFarmacia(int nitBuscado) {
    try {

        RandomAccessFile file = new RandomAccessFile(NOM_ARCHIVO, "rw");

        file.seek(0);

        while(file.getFilePointer() < file.length()) {

            long posicion = file.getFilePointer();

            int nit = file.readInt();
            String razonSocial = file.readUTF();
            String representanteLegal = file.readUTF();
            boolean stock = file.readBoolean();

            if(nit == nitBuscado) {

                file.seek(posicion);

                file.readInt();   // nombre
                file.readUTF();   // id
                file.readUTF();   // tipo
                file.writeBoolean(false); // marcar como eliminado

                file.close();
                return true;
            }
        }

        file.close();

    } catch(Exception e) {
        System.out.println("Error: " + e);
    }

    return false;
}
    

    public static boolean actualizarFarmacia(Farmacia far)
    {

        try {
            RandomAccessFile file = new RandomAccessFile(NOM_ARCHIVO, "rw");

            file.seek(0);

            while(file.getFilePointer() < file.length()){

                int nit = file.readInt();
                String razonSocial = file.readUTF();
                String represetanteLegal = file.readUTF();
                boolean estado = file.readBoolean();

                if(nit == far.getNit())
                {

                    file.seek(file.getFilePointer() - TAM_REGISTRO_FAR);
                    file.writeInt(far.getNit());
                    file.writeUTF(FuncionesMedicamento.adjustStringLength(far.getRazonSocial(), TAM_RAZON));
                    file.writeUTF(FuncionesMedicamento.adjustStringLength(far.getRepresetanteLegal(), TAM_REPRESENTANTE));
                    file.writeBoolean(far.isEstado());
                    file.close();
                    return true;
                }
            }
            file.close();
        } catch(Exception e){
            System.out.println("Error: " + e);
            return false;
        }
        return false;
    }
    
    public static int contarFarmacias()
    {
        int contador = 0;

        try {

            RandomAccessFile file = new RandomAccessFile(NOM_ARCHIVO, "rw");

            file.seek(0);

            while(file.getFilePointer() < file.length())
            {
                // lee registro completo
                file.readInt();      //
                file.readUTF();      // 
                file.readUTF();      // 
                file.readBoolean();  // 

                contador++;
            }

            file.close();

        } catch(Exception e){
            System.out.println("Error: " + e);
        }

        return contador;
    }
    
    
    
    public static String mostrarFarmacias()
    {
        StringBuilder info = new StringBuilder();

        try {

            RandomAccessFile file = new RandomAccessFile(NOM_ARCHIVO, "r");

            file.seek(0);

            while(file.getFilePointer() < file.length())
            {
                int nit = file.readInt();
                String razonSocial = file.readUTF();
                String represetanteLegal = file.readUTF();
                boolean estado = file.readBoolean();

                info.append("===== Farmacia =====\n");
                info.append("Nit: ").append(nit).append("\n");
                info.append("Razon Social: ").append(razonSocial).append("\n");
                info.append("Representante Legal: ").append(represetanteLegal).append("\n");
                info.append("Estado: ").append(estado ? "ACTIVO" : "NO ACTIVO").append("\n\n");
            }

            file.close();

        } catch(Exception e){
            return "Error al leer archivo";
        }

        return info.toString();
    }
}
