/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Backend;

import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import Backend.FuncionesFarmacia;
import Frontend.GUIPrincipal;
import javax.swing.JOptionPane;

/**
 *
 * @author AyLZz
 * 
 * Se maneja el siguiente orden para R & W en el registro:

 * private String nombre; (22)
    private String id; (14)
    private double gramaje; (8)
    private String tipoMedicamento; (17)
    private double precio; (8)
    private boolean Stock; (1)
    private int nitFarmacia; (4)
 */
public class FuncionesMedicamento 
{
    public static final int TAM_NOMBRE = 20;
    public static final int TAM_ID = 12;
    public static final int TAM_TIPO = 15;
    public static final int TAM_REGISTRO = 74;
    
    
    
    public static String adjustStringLength(String input, int n) {
        if (input == null) {
            return " ".repeat(n);
        }

        if (input.length() > n) {
            return input.substring(0, n);
        } else {
            return String.format("%-" + n + "s", input);
        }
    }
    
    public static boolean cargarEnArchivo(Medicamento med){
        
        Medicamento buscado = buscarMedicamento(med.getId());
    
        if(buscado != null){
            return false;
        }
        
        //Validar FK
        Farmacia buscada = FuncionesFarmacia.buscarFarmacia(med.getNitFarmacia());
        if (buscada == null){
            return false;
        }
        
        try 
        {
            RandomAccessFile file = new RandomAccessFile("data//registros.txt", "rw");            

            file.seek(file.length());
            file.writeUTF(adjustStringLength(med.getNombre(), TAM_NOMBRE));
            file.writeUTF(adjustStringLength(med.getId(), TAM_ID));
            file.writeDouble(med.getGramaje());
            file.writeUTF(adjustStringLength(med.getTipoMedicamento(), TAM_TIPO));
            file.writeDouble(med.getPrecio());
            file.writeBoolean(med.getStock());
            file.writeInt(med.getNitFarmacia());
            file.close();
        
        } catch (Exception ex) {
            Logger.getLogger(GUIPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
        return true;
    }

    public static List listarMedicamentos()
    {
        //Se declara una variable llamada medicamentos de tipo ArrayList que permite "almacenar" objetos de tipo Medicamento
        List <Medicamento> medicamentos = new ArrayList();
        String nombre;
        String id;
        double gramaje;
        String tipoMedicamento;
        double precio;
        boolean stock;
        int nitFarmacia;
        
        //Variable de tipo empleado - NO hay objeto aún
        Medicamento med;
        
        try 
        {
            RandomAccessFile file = new RandomAccessFile("data//registros.txt", "rw");
            //Se posiciona al inicio del archivo
            file.seek(0);
            while(file.getFilePointer() < file.length()){
                //Se leen los datos del archivo en el mismo orden en que fueron escritos
                nombre = file.readUTF();
                id = file.readUTF();
                gramaje = file.readDouble();
                tipoMedicamento = file.readUTF();
                precio = file.readDouble();
                stock = file.readBoolean();
                nitFarmacia = file.readInt();

                //Crea un objeto de tipo Empleado (emp) a partir de los valores leidos del archivo.
                
                med = new Medicamento(nombre, id, gramaje, tipoMedicamento, precio, stock, nitFarmacia);
                //Se adiciona al ArrayList empleados el empleado leido
                if(stock){
                    medicamentos.add(med);
                }
            }
            file.close();
        } catch (Exception ex) {
            System.out.println("Error! " + ex);
        }

        return medicamentos;
    }

    public static Medicamento buscarMedicamento(String idBuscada)
    {
        String nombre;
        String id;
        double gramaje;
        String tipoMedicamento;
        double precio;
        boolean stock;
        int nitFarmacia;
        
        Medicamento med = null;

        try {
            RandomAccessFile file = new RandomAccessFile("data//registros.txt", "rw");
            //Se posiciona al inicio del archivo
            file.seek(0);
            while(file.getFilePointer() < file.length()){
                //Se leen los datos del archivo en el mismo orden en que fueron escritos
                nombre = file.readUTF();
                id = file.readUTF();
                gramaje = file.readDouble();
                tipoMedicamento = file.readUTF();
                precio = file.readDouble();
                stock = file.readBoolean();
                nitFarmacia = file.readInt();

                if(id.trim().equals(idBuscada))
                {
                    med = new Medicamento(nombre, id, gramaje, tipoMedicamento, precio, stock, nitFarmacia);
                    file.close();
                    return med;
                    
                }
            }
            file.close();
        } catch (Exception ex) {
            System.out.println("Error! " + ex);
        }

        return null;
    }

    
    public static boolean eliminarMedicamento(String idBuscado) {
    try {

        RandomAccessFile file = new RandomAccessFile("data//registros.txt", "rw");

        file.seek(0);

        while(file.getFilePointer() < file.length()) {

            long posicion = file.getFilePointer();

            String nombre = file.readUTF();
            String id = file.readUTF();
            double gramaje = file.readDouble();
            String tipo = file.readUTF();
            double precio = file.readDouble();
            boolean stock = file.readBoolean();
            int nitFarmacia = file.readInt();

            if(id.trim().equals(idBuscado)) {

                file.seek(posicion);

                file.readUTF();   // nombre
                file.readUTF();   // id
                file.readDouble();// gramaje
                file.readUTF();   // tipo
                file.readDouble();// precio
                file.writeBoolean(false); // stock
                file.readInt(); //nitFarmacia
               

                file.close();
                return true;
            }
        }

        file.close();

    } catch(Exception e) {
        System.out.println("Error: " + e);
    }

    return false;
}

    public static boolean actualizarMedicamento(Medicamento med)
    {
        String nombre;
        String id;
        double gramaje;
        String tipoMedicamento;
        double precio;
        boolean stock;
        int nitFarmacia;

        try {

            RandomAccessFile file = new RandomAccessFile("data//registros.txt", "rw");

            file.seek(0);

            while(file.getFilePointer() < file.length()){

                nombre = file.readUTF();
                id = file.readUTF();
                gramaje = file.readDouble();
                tipoMedicamento = file.readUTF();
                precio = file.readDouble();
                stock = file.readBoolean();
                nitFarmacia = file.readInt();

                if(id.trim().equals(med.getId()))
                {
                    file.seek(file.getFilePointer() - TAM_REGISTRO);
                    file.writeUTF(adjustStringLength(med.getNombre(), TAM_NOMBRE));
                    file.writeUTF(adjustStringLength(med.getId(), TAM_ID));
                    file.writeDouble(med.getGramaje());
                    file.writeUTF(adjustStringLength(med.getTipoMedicamento(), TAM_TIPO));
                    file.writeDouble(med.getPrecio());
                    file.writeBoolean(med.getStock());
                    file.writeInt(med.getNitFarmacia());
                    file.close();
                    return true;
                }
            }
            file.close();
        } catch(Exception e){
            System.out.println("Error: " + e);
        }
        return false;
    }
    
    public static double sumarMedicamentos()
    {
        double suma = 0;

        try {

            RandomAccessFile file = new RandomAccessFile("data//registros.txt", "rw");

            file.seek(0);

            while(file.getFilePointer() < file.length())
            {
                // lee registro completo
                file.readUTF();      // nombre
                file.readUTF();      // id
                file.readDouble();   // gramaje
                file.readUTF();      // tipo
                suma += file.readDouble();   // precio
                file.readBoolean();  // stock
                file.readInt();      // nit Farmacia

            }

            file.close();

        } catch(Exception e){
            System.out.println("Error: " + e);
        }

        return suma;
    }
    
    
    
    public static String mostrarMedicamentos()
    {
        StringBuilder info = new StringBuilder();

        try {

            RandomAccessFile file = new RandomAccessFile("data//registros.txt", "r");

            file.seek(0);

            while(file.getFilePointer() < file.length())
            {
                String nombre = file.readUTF();
                String id = file.readUTF();
                double gramaje = file.readDouble();
                String tipo = file.readUTF();
                double precio = file.readDouble();
                boolean stock = file.readBoolean();
                int nitFarmacia = file.readInt();

                info.append("===== MEDICAMENTO =====\n");
                info.append("Nombre: ").append(nombre).append("\n");
                info.append("ID: ").append(id).append("\n");
                info.append("Gramaje: ").append(gramaje).append("\n");
                info.append("Tipo: ").append(tipo).append("\n");
                info.append("Precio: ").append(precio).append("\n");
                info.append("Stock: ").append(stock ? "Disponible" : "Agotado").append("\n");
                info.append("Nit Farmacia: ").append(nitFarmacia).append("\n");
            }

            file.close();

        } catch(Exception e){
            return "Error al leer archivo";
        }

        return info.toString();
    }
    
}