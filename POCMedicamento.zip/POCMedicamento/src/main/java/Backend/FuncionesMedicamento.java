/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Backend;

import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import Frontend.GUIPrincipal;
import javax.swing.JOptionPane;

/**
 *
 * @author AyLZz
 * 
 * Se maneja el siguiente orden para R & W en el registro:

 * private String nombre;
    private String id;
    private double gramaje;
    private String tipoMedicamento;
    private double precio;
    private boolean Stock;
 */
public class FuncionesMedicamento 
{
    
    public static boolean cargarEnArchivo(Medicamento med){
        try 
        {
            RandomAccessFile file = new RandomAccessFile("data//registros.txt", "rw");            
            
            file.seek(file.length());
            
            file.writeUTF(med.getNombre());
            file.writeUTF(med.getId());
            file.writeDouble(med.getGramaje());
            file.writeUTF(med.getTipoMedicamento());
            file.writeDouble(med.getPrecio());
            file.writeBoolean(med.getStock());
            
            file.close();
        
        } catch (Exception ex) {
            Logger.getLogger(GUIPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
        return true;
    }

    public static List listarMedicamentos()
    {
        //Se declara una variable llamada medicamentos de tipo ArrayList que permite "almacenar" objetos de tipo Medicamento
        List <Medicamento> medicamentos = new ArrayList();
        String nombre;
        String id;
        double gramaje;
        String tipoMedicamento;
        double precio;
        boolean stock;
        
        //Variable de tipo empleado - NO hay objeto aún
        Medicamento med;
        
        try 
        {
            RandomAccessFile file = new RandomAccessFile("data//registros.txt", "rw");
            //Se posiciona al inicio del archivo
            file.seek(0);
            while(file.getFilePointer() < file.length()){
                //Se leen los datos del archivo en el mismo orden en que fueron escritos
                nombre = file.readUTF();
                id = file.readUTF();
                gramaje = file.readDouble();
                tipoMedicamento = file.readUTF();
                precio = file.readDouble();
                stock = file.readBoolean();

                //Crea un objeto de tipo Empleado (emp) a partir de los valores leidos del archivo. 
                med = new Medicamento(nombre, id, gramaje, tipoMedicamento, precio, stock);
                //Se adiciona al ArrayList empleados el empleado leido
                medicamentos.add(med);
            }
            file.close();
        } catch (Exception ex) {
            System.out.println("Error! " + ex);
        }

        return medicamentos;
    }

    public static Medicamento buscarMedicamento(String id)
    {
        String nombre;
        String idLeida;
        double gramaje;
        String tipoMedicamento;
        double precio;
        boolean stock;

        Medicamento med = null;

        try {
            RandomAccessFile file = new RandomAccessFile("data//registros.txt", "rw");
            //Se posiciona al inicio del archivo
            file.seek(0);
            while(file.getFilePointer() < file.length()){
                //Se leen los datos del archivo en el mismo orden en que fueron escritos
                nombre = file.readUTF();
                idLeida = file.readUTF();
                gramaje = file.readDouble();
                tipoMedicamento = file.readUTF();
                precio = file.readDouble();
                stock = file.readBoolean();

                if(idLeida.equals(id))
                {
                    med = new Medicamento(nombre, idLeida, gramaje, tipoMedicamento, precio, stock);
                    break;
                    
                }
                else
                {
                    med = null;
                }
            }
            file.close();
        } catch (Exception ex) {
            System.out.println("Error! " + ex);
        }

        return med;
    }

    
    public static boolean eliminarMedicamento(String id)
    {
        boolean eliminado = false;

    try {
        RandomAccessFile file = new RandomAccessFile("data//registros.txt", "rw");

        RandomAccessFile tempFile = new RandomAccessFile("data//temp.txt", "rw");
                

        file.seek(0);

        while(file.getFilePointer() < file.length()){

            String nombre = file.readUTF();
            String idLeida = file.readUTF();
            double gramaje = file.readDouble();
            String tipoMedicamento = file.readUTF();
            double precio = file.readDouble();
            boolean stock = file.readBoolean();

            if(!idLeida.equals(id)){
                tempFile.writeUTF(nombre);
                tempFile.writeUTF(idLeida);
                tempFile.writeDouble(gramaje);
                tempFile.writeUTF(tipoMedicamento);
                tempFile.writeDouble(precio);
                tempFile.writeBoolean(stock);
            } else {
                eliminado = true;
            }
        }

        file.close();
        tempFile.close();

        java.io.File original = new java.io.File("data//registros.txt");

        java.io.File temp = new java.io.File("data//temp.txt");

        if(eliminado){
            original.delete();
            temp.renameTo(original);
        } else {
            temp.delete();
        }

    } catch (Exception ex) {
        System.out.println("Error! " + ex);
        return false;
    }

    return eliminado;
    }

    public static boolean actualizarMedicamento(String idBuscar,Medicamento nuevoMed)
    {
        boolean actualizado = false;

        try {

            RandomAccessFile file = new RandomAccessFile("data//registros.txt", "r");

            RandomAccessFile tempFile = new RandomAccessFile("data//temp.txt", "rw");

            file.seek(0);

            while(file.getFilePointer() < file.length()){

                String nombre = file.readUTF();
                String idLeida = file.readUTF();
                double gramaje = file.readDouble();
                String tipoMedicamento = file.readUTF();
                double precio = file.readDouble();
                boolean stock = file.readBoolean();

                if(idLeida.equals(idBuscar))
                {

                    tempFile.writeUTF(nuevoMed.getNombre());
                    tempFile.writeUTF(nuevoMed.getId());
                    tempFile.writeDouble(nuevoMed.getGramaje());
                    tempFile.writeUTF(nuevoMed.getTipoMedicamento());
                    tempFile.writeDouble(nuevoMed.getPrecio());
                    tempFile.writeBoolean(nuevoMed.getStock());

                    actualizado = true;
                }
                else
                {
                    // copiar registro original
                    tempFile.writeUTF(nombre);
                    tempFile.writeUTF(idLeida);
                    tempFile.writeDouble(gramaje);
                    tempFile.writeUTF(tipoMedicamento);
                    tempFile.writeDouble(precio);
                    tempFile.writeBoolean(stock);
                }
            }

            file.close();
            tempFile.close();

            java.io.File original =new java.io.File("data//registros.txt");

            java.io.File temp =new java.io.File("data//temp.txt");

            if(actualizado){
                original.delete();
                temp.renameTo(original);
            } else {
                temp.delete();
            }

        } catch(Exception e){
            System.out.println("Error: " + e);
            return false;
        }

        return actualizado;
    }
    
    public static int contarMedicamentos()
    {
        int contador = 0;

        try {

            RandomAccessFile file = new RandomAccessFile("data//registros.txt", "rw");

            file.seek(0);

            while(file.getFilePointer() < file.length())
            {
                // lee registro completo
                file.readUTF();      // nombre
                file.readUTF();      // id
                file.readDouble();   // gramaje
                file.readUTF();      // tipo
                file.readDouble();   // precio
                file.readBoolean();  // stock

                contador++;
            }

            file.close();

        } catch(Exception e){
            System.out.println("Error: " + e);
        }

        return contador;
    }
    
    
    
    public static String mostrarMedicamentos()
    {
        StringBuilder info = new StringBuilder();

        try {

            RandomAccessFile file = new RandomAccessFile("data//registros.txt", "r");

            file.seek(0);

            while(file.getFilePointer() < file.length())
            {
                String nombre = file.readUTF();
                String id = file.readUTF();
                double gramaje = file.readDouble();
                String tipo = file.readUTF();
                double precio = file.readDouble();
                boolean stock = file.readBoolean();

                info.append("===== MEDICAMENTO =====\n");
                info.append("Nombre: ").append(nombre).append("\n");
                info.append("ID: ").append(id).append("\n");
                info.append("Gramaje: ").append(gramaje).append("\n");
                info.append("Tipo: ").append(tipo).append("\n");
                info.append("Precio: ").append(precio).append("\n");
                info.append("Stock: ").append(stock ? "Disponible" : "Agotado").append("\n\n");
            }

            file.close();

        } catch(Exception e){
            return "Error al leer archivo";
        }

        return info.toString();
    }
    
}