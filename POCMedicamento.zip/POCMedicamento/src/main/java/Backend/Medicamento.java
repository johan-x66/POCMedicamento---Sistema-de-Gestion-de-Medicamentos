/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Backend;

/**
 *
 * @author AyLZz
 */
public class Medicamento 
{
    
    //Atributos escenciales. (La idea es añadir unos cuantos mas en un futuro)
    
    private String nombre;
    private String id;
    private double gramaje;
    private String tipoMedicamento;
    private double precio;
    private boolean Stock;
    private int nitFarmacia;

    public Medicamento(String nombre, String id, double gramaje, String tipoMedicamento, double precio, boolean Stock, int nitFarmacia) {
        this.nombre = nombre;
        this.id = id;
        this.gramaje = gramaje;
        this.tipoMedicamento = tipoMedicamento;
        this.precio = precio;
        this.Stock = Stock;
        this.nitFarmacia = nitFarmacia;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public double getGramaje() {
        return gramaje;
    }

    public void setGramaje(double gramaje) {
        this.gramaje = gramaje;
    }

    public String getTipoMedicamento() {
        return tipoMedicamento;
    }

    public void setTipoMedicamento(String tipoMedicamento) {
        this.tipoMedicamento = tipoMedicamento;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public boolean getStock() {
        return Stock;
    }

    public void setStock(boolean Stock) {
        this.Stock = Stock;
    } 

    public int getNitFarmacia() {
        return nitFarmacia;
    }

    public void setNitFarmacia(int nitFarmacia) {
        this.nitFarmacia = nitFarmacia;
    }
    
    
}
