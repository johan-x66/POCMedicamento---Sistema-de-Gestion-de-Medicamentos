/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pocmedicamento;

import Frontend.GUIPrincipal;

/**
 *
 * @author laura
 */
public class POCMedicamento {

    public static void main(String[] args) {
        GUIPrincipal gui = new GUIPrincipal();
        gui.setVisible(true);
    }
}
